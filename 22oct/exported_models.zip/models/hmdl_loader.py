
import struct, zlib, hashlib, json
import numpy as np

MAGIC, SUPPORTED_FORMAT = b'HMDL', 1

class HeartModel:
    def __init__(self, path):
        b = open(path, 'rb').read()
        if b[:4] != MAGIC: raise ValueError('Not an HMDL file')
        fmt, n = struct.unpack('<HI', b[4:10])
        if fmt > SUPPORTED_FORMAT: raise ValueError(f'Format v{fmt} not supported, update loader')
        self.meta = json.loads(b[10:10 + n]); payload = b[10 + n:]
        if hashlib.sha256(payload).hexdigest() != self.meta['sha256']: raise ValueError('Checksum mismatch: file corrupted')
        raw = zlib.decompress(payload) if self.meta['compressed'] else payload
        a = np.frombuffer(raw, dtype=self.meta['dtype']).astype(float); k = self.meta['n_features']
        self.mean, self.std, self.coef, self.intercept = a[:k], a[k:2 * k], a[2 * k:3 * k], a[3 * k]

    def predict_proba(self, X):
        X = np.asarray(X, dtype=float)
        if X.shape[1] != self.meta['n_features']: raise ValueError(f"Expected {self.meta['n_features']} features")
        return 1 / (1 + np.exp(-(((X - self.mean) / self.std) @ self.coef + self.intercept)))

    def predict(self, X): return (self.predict_proba(X) > 0.5).astype(int)
